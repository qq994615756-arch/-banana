module.exports=[12923,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generate_status_route_actions_0gw_~iu.js.map