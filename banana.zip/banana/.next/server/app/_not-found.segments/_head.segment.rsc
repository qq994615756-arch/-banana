1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/03k9cnlt-2733.js","/_next/static/chunks/0mc.xzdwkp~zy.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/03k9cnlt-2733.js","/_next/static/chunks/0mc.xzdwkp~zy.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0a0a0a"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"FlowAI - 智能画布工作台"}],["$","meta","1",{"name":"description","content":"基于AI的智能画布工作台，支持多模型对话、图片上传、项目管理等功能"}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"zn8PKt8US6ukaQJ37dd0h"}
