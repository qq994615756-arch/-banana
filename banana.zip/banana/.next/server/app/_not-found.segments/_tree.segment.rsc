:HL["/_next/static/chunks/0r.mdywrpnqca.css","style"]
:HL["/_next/static/chunks/17asoemmq~e_f.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"zn8PKt8US6ukaQJ37dd0h"}
