var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__0m7k89~._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__134yvnb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_route_actions_0fkkm_2.js")
R.m(39856)
module.exports=R.m(39856).exports
