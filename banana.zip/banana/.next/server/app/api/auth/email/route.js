var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/email/route.js")
R.c("server/chunks/[root-of-the-server]__0fnykvt._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__134yvnb._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_email_route_actions_0ebhkkp.js")
R.m(16691)
module.exports=R.m(16691).exports
