var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/status/route.js")
R.c("server/chunks/[root-of-the-server]__0k00w2x._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__134yvnb._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_status_route_actions_0gw_~iu.js")
R.m(63353)
module.exports=R.m(63353).exports
