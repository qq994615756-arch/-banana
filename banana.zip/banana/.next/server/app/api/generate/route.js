var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/[root-of-the-server]__0tcgtiq._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/[root-of-the-server]__134yvnb._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_0fw79e2.js")
R.m(3476)
module.exports=R.m(3476).exports
