var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/route.js")
R.c("server/chunks/[root-of-the-server]__0e4-t7i._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_route_actions_09u5xm8.js")
R.m(98098)
module.exports=R.m(98098).exports
