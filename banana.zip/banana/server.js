const express = require('express');
const cors = require('cors');
//const fetch = require('node-fetch');
const { OAuth2Client } = require('google-auth-library');
const jwt = require('jsonwebtoken');

const app = express();
const allowedOrigins = [
  'http://localhost:3000',
  'http://banana-six-mu.vercel.app',
  'https://banana-six-mu.vercel.app',
  'http://banana-nnuxe4ul8-qq994615756-7066s-projects.vercel.app',
  'https://banana-nnuxe4ul8-qq994615756-7066s-projects.vercel.app',
];

function isAllowedOrigin(origin) {
  if (allowedOrigins.includes(origin)) return true;
  // Allow Vercel preview domains for this project namespace.
  return /^https?:\/\/banana-[a-z0-9-]+-qq994615756-7066s-projects\.vercel\.app$/i.test(origin);
}

const corsOptions = {
  origin(origin, callback) {
    // Allow server-to-server requests or curl without Origin header.
    if (!origin) return callback(null, true);
    if (isAllowedOrigin(origin)) return callback(null, true);
    return callback(new Error(`CORS blocked origin: ${origin}`));
  },
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: false,
  optionsSuccessStatus: 204,
};

app.use(cors(corsOptions));
//app.options('*', cors(corsOptions));
app.use(express.json({ limit: '50mb' }));

// ================= 配置区 =================
const NANO_API_KEY = 'sk-2728e945f2e24039b3b0f33186339d0d';
const GOOGLE_CLIENT_ID = '751867797576-7fq3t616j5r0s69ls93d36s2mitevi73.apps.googleusercontent.com';
const JWT_SECRET = 'a587670ae1ba2e8fc2cc91c6df3844eab3d38cdbeaf106b515025ed75ed0afb4'; // 建议更换为随机字符串
const NANO_BASE_URL = 'https://grsai.dakka.com.cn'; // 根据文档地址填写

// 延迟函数
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// 分辨率映射：前端数字 -> Nano 规格
function mapResolution(res) {
  if (res >= 4096) return '4K';
  if (res >= 2048) return '2K';
  return '1K';
}

// ================= 1. Google 登录接口 =================
app.post('/api/auth/google', async (req, res) => {
  try {
    const { token } = req.body; // 前端传过来的 access_token

    // 使用 access_token 向 Google 请求获取用户真实信息
    const userInfoRes = await fetch(`https://www.googleapis.com/oauth2/v3/userinfo?access_token=${token}`);
    const payload = await userInfoRes.json();
    
    if (!userInfoRes.ok || !payload.sub) {
      throw new Error('无效的 Google Token');
    }

    // 构造用户信息
    const userData = {
      id: payload.sub,
      email: payload.email,
      name: payload.name,
      avatar: payload.picture,
    };

    // 生成你自己的 JWT Token
    const appToken = jwt.sign(userData, JWT_SECRET, { expiresIn: '7d' });
    
    // 返回给前端
    res.json({ code: 0, data: { token: appToken, user: userData } });
  } catch (error) {
    console.error('Google Auth Error:', error.message);
    res.status(401).json({ code: -1, msg: 'Google 验证失败' });
  }
});

// ================= 2. 提交生图任务接口 (第一步：只发号牌，秒回) =================
app.post('/api/generate', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: '请先登录' });

  try {
    const { prompt, model, ratio, resolution, quantity = 1, images } = req.body;
    console.log('🚀 前端来派单了，准备提交给第三方...');

    // 直接提交给第三方 API
    const submitRes = await fetch(`${NANO_BASE_URL}/v1/draw/nano-banana`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${NANO_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: model || 'nano-banana-pro',
        prompt,
        aspectRatio: ratio || '1:1',
        imageSize: mapResolution(resolution),
        webHook: "-1", 
        urls: images
      })
    });

    const submitData = await submitRes.json();
    if (submitData.code !== 0) throw new Error(submitData.msg);

    const taskId = submitData.data.id;
    console.log(`✅ 接单成功，发给前端的号牌: ${taskId}`);

    // 【关键】不再死等，把真实 ID 包装好，立刻扔给前端
    res.json({
      code: 0,
      msg: 'success',
      taskId: taskId,            // 格式1
      data: { taskId: taskId }   // 格式2 (双重保险)
    });

  } catch (error) {
    console.error('❌ 提交任务发生致命错误:', error);
    res.status(500).json({ error: error.message });
  }
});

// ================= 3. 查询任务状态接口 (第二步：专门接待前端的轮询) =================
app.get('/api/generate/status', async (req, res) => {
  try {
    const taskId = req.query.taskId; // 获取前端带来的号牌
    if (!taskId) return res.status(400).json({ error: '缺少 taskId' });

    // 拿着号牌去问第三方 API 画好了没
    const resultRes = await fetch(`${NANO_BASE_URL}/v1/draw/result`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${NANO_API_KEY}`
      },
      body: JSON.stringify({ id: taskId })
    });

    const resultData = await resultRes.json();

    // 如果还没画完 (processing)
    if (!resultData.data || resultData.data.status === 'processing' || resultData.data.status === 'starting') {
      return res.json({ 
        code: 0, 
        status: 'processing',
        data: { status: 'processing' } 
      });
    }

    // 如果画成功了 (succeeded)
    if (resultData.data.status === 'succeeded') {
      const imageUrls = resultData.data.results.map(img => img.url);
      console.log('🎉 画完啦！把图片交给前端:', imageUrls);
      return res.json({
        code: 0,
        msg: 'success',
        status: 'succeeded',
        images: imageUrls,
        data: {
          status: 'succeeded',
          images: imageUrls,
          results: resultData.data.results, // 完美还原 Grsai 原生格式 [{url: '...'}]
          url: imageUrls[0]                 // 满足直接读 url 的前端需求
        }
      });
    }

    // 如果失败了 (failed)
    return res.json({ code: -1, msg: resultData.data.error || '生成失败' });

  } catch (error) {
    console.error('❌ 查询状态报错:', error);
    res.status(500).json({ error: error.message });
  }
});

// ================= 3. 邮箱登录接口 (带白名单限制) =================
app.post('/api/auth/email', (req, res) => {
  try {
    const { email } = req.body; // 获取前端传来的邮箱

    // 🛑 白名单检查：只允许你的邮箱
    if (email !== '1065499853@qq.com') {
      return res.status(403).json({ code: -1, msg: '未经授权的访问' });
    }

    const mockUser = {
      id: 'admin-001',
      email: '1065499853@qq.com',
      name: '项目主理人',
      avatar: ''
    };

    // 生成 JWT Token 
    const appToken = jwt.sign(mockUser, JWT_SECRET, { expiresIn: '7d' });
    
    res.json({ code: 0, data: { token: appToken, user: mockUser } });
  } catch (error) {
    console.error('Login Error:', error);
    res.status(500).json({ code: -1, msg: '登录异常' });
  }
});

app.listen(8000, '0.0.0.0', () => console.log('Backend running on port 8000'));
